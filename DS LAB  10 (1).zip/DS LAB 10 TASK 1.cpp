#include <iostream>
using namespace std;

class CircularQueue {
private:
    int* arr;
    int size;
    int front;
    int rear;

public:
    CircularQueue(int s) {
        size = s;
        arr = new int[size];
        front = -1;
        rear = -1;
    }

    bool isFull() {
        return ((rear + 1) % size == front);
    }

    bool isEmpty() {
        return (front == -1);
    }

    void enQueue(int val) {
        if (isFull()) {
            cout << "Queue is full! Cannot insert " << val << endl;
            return;
        }
        if (isEmpty()) {
            front = rear = 0;
        } else {
            rear = (rear + 1) % size;
        }
        arr[rear] = val;
        cout << "enQueue(" << val << ") -> ";
        display();
    }

    void deQueue() {
        if (isEmpty()) {
            cout << "Queue is empty! Cannot dequeue" << endl;
            return;
        }
        int removed = arr[front];
        if (front == rear) { 
            front = rear = -1;
        } else {
            front = (front + 1) % size;
        }
        cout << "deQueue() removed " << removed << " -> ";
        display();
    }

    void display() {
        cout << "Front: " << front << ", Rear: " << rear << ", Array: [";
        for (int i = 0; i < size; i++) {
            if (i == front || i == rear || (!isEmpty() && (front < rear ? (i >= front && i <= rear) : (i >= front || i <= rear))))
                cout << arr[i];
            else
                cout << "_";
            if (i != size - 1) cout << ", ";
        }
        cout << "]" << endl;
    }
};

int main() {
    CircularQueue q(5);

    q.enQueue(10);
    q.enQueue(20);
    q.enQueue(30);
    q.deQueue();
    q.enQueue(40);
    q.enQueue(50);
    q.enQueue(60);

    return 0;
}