#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* next;
    Node(int val) {
        data = val;
        next = NULL;
    }
};

class Queue {
private:
    Node* front;
    Node* rear;
public:
    Queue() {
        front = rear = NULL;
    }

    void enqueue(int value) {
        Node* newNode = new Node(value);
        if (!rear) front = rear = newNode;
        else {
            rear->next = newNode;
            rear = newNode;
        }
        cout << "Inserted: " << value << endl;
    }

    void dequeue() {
        if (!front) {
            cout << "Queue Underflow!\n";
            return;
        }
        Node* temp = front;
        cout << "Deleted: " << temp->data << endl;
        front = front->next;
        if (!front) rear = NULL;
        delete temp;
    }

    void display() {
        if (!front) {
            cout << "Queue is Empty!\n";
            return;
        }
        Node* temp = front;
        cout << "Queue Elements: ";
        while (temp) {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }

    int count() {
        int cnt = 0;
        Node* temp = front;
        while (temp) {
            cnt++;
            temp = temp->next;
        }
        return cnt;
    }
};

int main() {
    Queue q;
    int choice, value;
    do {
        cout << "\n--- Queue Menu ---\n";
        cout << "1. Enqueue\n2. Dequeue\n3. Display\n4. Count Elements\n5. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch(choice) {
            case 1:
                cout << "Enter value: ";
                cin >> value;
                q.enqueue(value);
                break;
            case 2:
                q.dequeue();
                break;
            case 3:
                q.display();
                break;
            case 4:
                cout << "Number of elements: " << q.count() << endl;
                break;
            case 5:
                cout << "Exiting program.\n";
                break;
            default:
                cout << "Invalid choice!\n";
        }
    } while(choice != 5);
    return 0;
}