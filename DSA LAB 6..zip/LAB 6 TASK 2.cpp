#include <iostream>
using namespace std;

// Inventory Class
class Inventory {
private:
    int serialNum;
    int manufactYear;
    int lotNum;

public:
    // Set values
    void setData(int s, int y, int l) {
        serialNum = s;
        manufactYear = y;
        lotNum = l;
    }

    // Display values
    void display() {
        cout << "Serial Number: " << serialNum << endl;
        cout << "Manufacturing Year: " << manufactYear << endl;
        cout << "Lot Number: " << lotNum << endl;
        cout << "-----------------------" << endl;
    }
};

// Node for Linked List
class Node {
public:
    Inventory part;
    Node* next;

    Node(Inventory p) {
        part = p;
        next = NULL;
    }
};

// Stack Class
class Stack {
private:
    Node* top;

public:
    Stack() {
        top = NULL;
    }

    // Push function
    void push(Inventory p) {
        Node* newNode = new Node(p);
        newNode->next = top;
        top = newNode;
        cout << "Part added to inventory.\n";
    }

    // Pop function
    void pop() {
        if (top == NULL) {
            cout << "Inventory Stack is empty.\n";
            return;
        }

        Node* temp = top;

        cout << "\nPart removed from inventory:\n";
        top->part.display();

        top = top->next;
        delete temp;
    }

    // Display remaining parts
    void displayStack() {
        if (top == NULL) {
            cout << "No parts remaining in inventory.\n";
            return;
        }

        Node* temp = top;

        cout << "\nRemaining Parts in Inventory:\n";

        while (temp != NULL) {
            temp->part.display();
            temp = temp->next;
        }
    }
};

int main() {
    Stack inventoryStack;
    int choice;

    do {
        cout << "\n1. Add Part to Inventory\n";
        cout << "2. Take Part from Inventory\n";
        cout << "3. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        if (choice == 1) {
            int serial, year, lot;

            cout << "Enter Serial Number: ";
            cin >> serial;

            cout << "Enter Manufacturing Year: ";
            cin >> year;

            cout << "Enter Lot Number: ";
            cin >> lot;

            Inventory part;
            part.setData(serial, year, lot);

            inventoryStack.push(part);
        }

        else if (choice == 2) {
            inventoryStack.pop();
        }

    } while (choice != 3);

    // Display remaining parts
    inventoryStack.displayStack();

    return 0;
}