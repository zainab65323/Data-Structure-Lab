#include <iostream>
using namespace std;

class Node {
public:
    string title;
    float price;
    int edition;
    int pages;
    Node* next;

    Node(string t, float p, int e, int pg) {
        title = t;
        price = p;
        edition = e;
        pages = pg;
        next = NULL;
    }
};

class Stack {
private:
    Node* top;

public:
    Stack() {
        top = NULL;
    }

    // Push book onto stack
    void push(string t, float p, int e, int pg) {
        Node* newNode = new Node(t, p, e, pg);
        newNode->next = top;
        top = newNode;
        cout << "Book pushed: " << t << endl;
    }

    // Pop book from stack
    void pop() {
        if (top == NULL) {
            cout << "Stack Underflow\n";
            return;
        }
        Node* temp = top;
        cout << "Popped Book: " << top->title << endl;
        top = top->next;
        delete temp;
    }

    // Peek top book
    void peek() {
        if (top == NULL) {
            cout << "Stack is empty\n";
            return;
        }
        cout << "\nTop Book Details:\n";
        cout << "Title: " << top->title << endl;
        cout << "Price: " << top->price << endl;
        cout << "Edition: " << top->edition << endl;
        cout << "Pages: " << top->pages << endl;
    }

    // Display stack
    void display() {
        if (top == NULL) {
            cout << "Stack is empty\n";
            return;
        }

        Node* temp = top;
        cout << "\nRemaining Books in Stack:\n";

        while (temp != NULL) {
            cout << "Title: " << temp->title << endl;
            cout << "Price: " << temp->price << endl;
            cout << "Edition: " << temp->edition << endl;
            cout << "Pages: " << temp->pages << endl;
            cout << "-------------------\n";
            temp = temp->next;
        }
    }
};

int main() {
    Stack s;

    // 1. Push 5 books
    s.push("C++ Programming", 45.5, 3, 500);
    s.push("Data Structures", 55.0, 2, 620);
    s.push("Algorithms", 60.0, 1, 700);
    s.push("Operating Systems", 50.0, 4, 650);
    s.push("Database Systems", 48.0, 3, 540);

    // 2. Find top element
    s.peek();

    // 3. Pop 2 books
    s.pop();
    s.pop();

    // 4. Display remaining books
    s.display();

    return 0;
}