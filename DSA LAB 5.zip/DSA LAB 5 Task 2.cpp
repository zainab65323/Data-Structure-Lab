#include <iostream>
using namespace std;


struct Node {
    double rainfall;
    Node* next;
    Node* prev;
};


Node* createNode(double value) {
    Node* newNode = new Node;
    newNode->rainfall = value;
    newNode->next = nullptr;
    newNode->prev = nullptr;
    return newNode;
}


void insertEnd(Node*& head, double value) {
    Node* newNode = createNode(value);

    if (head == nullptr) {
        head = newNode;
        return;
    }

    Node* temp = head;
    while (temp->next != nullptr) {
        temp = temp->next;
    }

    temp->next = newNode;
    newNode->prev = temp;
}

int main() {
    Node* head = nullptr;
    double rainfall;
    double total = 0;
    int days = 7;

    cout << "Enter rainfall for 7 days:\n";


    for (int i = 1; i <= days; i++) {
        do {
            cout << "Day " << i << ": ";
            cin >> rainfall;

            if (rainfall < 0) {
                cout << "Rainfall cannot be negative. Please re-enter.\n";
            }

        } while (rainfall < 0);

        insertEnd(head, rainfall);
    }

    
    Node* temp = head;
    double highest = head->rainfall;
    double lowest = head->rainfall;
    int highDay = 1, lowDay = 1;
    int currentDay = 1;

    while (temp != nullptr) {
        total += temp->rainfall;

        if (temp->rainfall > highest) {
            highest = temp->rainfall;
            highDay = currentDay;
        }

        if (temp->rainfall < lowest) {
            lowest = temp->rainfall;
            lowDay = currentDay;
        }

        temp = temp->next;
        currentDay++;
    }

    double average = total / days;

    
    temp = head;
    for (int i = 1; i < 5 && temp != nullptr; i++) {
        temp = temp->next;
    }

    double afterFifth = 0;
    bool exists = false;

    if (temp != nullptr && temp->next != nullptr) {
        afterFifth = temp->next->rainfall;
        exists = true;
    }


    cout << "\n--- Weekly Rainfall Report ---\n";
    cout << "Total Rainfall: " << total << endl;
    cout << "Average Rainfall: " << average << endl;
    cout << "Highest Rainfall: " << highest << " (Day " << highDay << ")\n";
    cout << "Lowest Rainfall: " << lowest << " (Day " << lowDay << ")\n";

    if (exists)
        cout << "Rainfall of day after 5th node: " << afterFifth << endl;
    else
        cout << "No day exists after the 5th node.\n";

    return 0;
}